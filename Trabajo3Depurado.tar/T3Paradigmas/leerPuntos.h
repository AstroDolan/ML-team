#pragma once
#include <vector>
#include <string>
#include "Punto.h"

std::vector<Punto> leerPuntos(const std::string& nombreArchivo);
