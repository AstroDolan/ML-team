#pragma once
#include "Triangulo.h"
#include <set>

std::set<Triangulo> generarTriangulosDesdeAristas(const std::set<Arista>& aristas);
